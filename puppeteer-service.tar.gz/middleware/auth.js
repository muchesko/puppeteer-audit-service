import crypto from 'crypto';
import { config } from '../config/index.js';
export const authMiddleware = (req, res, next) => {
    const signature = req.headers['x-signature'];
    if (!signature) {
        return res.status(401).json({ error: 'Missing signature header' });
    }
    // Verify HMAC signature
    try {
        const body = JSON.stringify(req.body);
        const expectedSignature = `sha256=${crypto
            .createHmac('sha256', config.apiSecretKey)
            .update(body)
            .digest('hex')}`;
        if (!crypto.timingSafeEqual(Buffer.from(expectedSignature), Buffer.from(signature))) {
            return res.status(401).json({ error: 'Invalid signature' });
        }
        req.isValidSignature = true;
    }
    catch (error) {
        return res.status(401).json({ error: 'Invalid signature format' });
    }
    next();
};
