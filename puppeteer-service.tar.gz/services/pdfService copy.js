import puppeteer from 'puppeteer';
import { config } from '../config/index.js';
export class PDFService {
    activeBrowser = null;
    async getBrowser() {
        if (!this.activeBrowser || !this.activeBrowser.isConnected()) {
            this.activeBrowser = await puppeteer.launch({
                headless: true,
                executablePath: config.chromeExecutablePath,
                args: [
                    // Security flags
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-dev-shm-usage',
                    '--disable-gpu',
                    '--no-first-run',
                    '--no-zygote',
                    '--single-process',
                    // Network and connectivity fixes
                    '--disable-web-security',
                    '--disable-features=VizDisplayCompositor',
                    '--disable-background-networking',
                    '--disable-background-timer-throttling',
                    '--disable-backgrounding-occluded-windows',
                    '--disable-renderer-backgrounding',
                    '--disable-ipc-flooding-protection',
                    // Chrome stability flags
                    '--disable-extensions',
                    '--disable-default-apps',
                    '--disable-sync',
                    '--no-default-browser-check',
                    '--no-pings',
                    '--disable-features=TranslateUI',
                    // Memory management
                    '--memory-pressure-off',
                    '--max_old_space_size=4096',
                    // Additional fixes for containerized environments
                    '--disable-dev-tools',
                    '--disable-gpu-sandbox',
                    '--disable-software-rasterizer',
                    '--remote-debugging-port=0',
                    '--disable-background-mode'
                ],
                timeout: 30000,
                protocolTimeout: 30000,
                handleSIGINT: false,
                handleSIGTERM: false,
                handleSIGHUP: false
            });
        }
        return this.activeBrowser;
    }
    async generatePDF(request) {
        // Add retry logic for browser launch
        let browser;
        let retryCount = 0;
        const maxRetries = 3;
        while (retryCount < maxRetries) {
            try {
                browser = await this.getBrowser();
                break;
            }
            catch (error) {
                retryCount++;
                console.error(`Browser launch attempt ${retryCount} failed:`, error);
                console.error('Chrome executable path:', config.chromeExecutablePath);
                console.error('Error details:', error instanceof Error ? error.stack : error);
                if (retryCount >= maxRetries) {
                    throw new Error(`Failed to launch browser after ${maxRetries} attempts`);
                }
                // Clean up any existing browser
                if (this.activeBrowser) {
                    try {
                        await this.activeBrowser.close();
                    }
                    catch (e) {
                        // Ignore cleanup errors
                    }
                    this.activeBrowser = null;
                }
                // Wait before retry
                await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
            }
        }
        const page = await browser.newPage();
        try {
            // Set content
            await page.setContent(request.htmlContent, {
                waitUntil: 'networkidle0',
                timeout: config.requestTimeout
            });
            // Configure PDF options
            const pdfOptions = {
                format: request.options?.format || 'A4',
                landscape: request.options?.orientation === 'landscape',
                margin: {
                    top: request.options?.margin?.top || '1cm',
                    right: request.options?.margin?.right || '1cm',
                    bottom: request.options?.margin?.bottom || '1cm',
                    left: request.options?.margin?.left || '1cm'
                },
                displayHeaderFooter: request.options?.displayHeaderFooter || false,
                headerTemplate: request.options?.headerTemplate || '',
                footerTemplate: request.options?.footerTemplate || '',
                printBackground: request.options?.printBackground !== false,
                scale: request.options?.scale || 1,
                timeout: config.requestTimeout
            };
            // Generate PDF
            const pdfData = await page.pdf(pdfOptions);
            return Buffer.from(pdfData);
        }
        finally {
            await page.close();
        }
    }
    async generatePDFFromURL(url, options) {
        // Add retry logic for browser launch
        let browser;
        let retryCount = 0;
        const maxRetries = 3;
        while (retryCount < maxRetries) {
            try {
                browser = await this.getBrowser();
                break;
            }
            catch (error) {
                retryCount++;
                console.error(`Browser launch attempt ${retryCount} failed:`, error);
                console.error('Chrome executable path:', config.chromeExecutablePath);
                console.error('Error details:', error instanceof Error ? error.stack : error);
                if (retryCount >= maxRetries) {
                    throw new Error(`Failed to launch browser after ${maxRetries} attempts`);
                }
                // Clean up any existing browser
                if (this.activeBrowser) {
                    try {
                        await this.activeBrowser.close();
                    }
                    catch (e) {
                        // Ignore cleanup errors
                    }
                    this.activeBrowser = null;
                }
                // Wait before retry
                await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
            }
        }
        const page = await browser.newPage();
        try {
            // Navigate to URL
            await page.goto(url, {
                waitUntil: 'networkidle2',
                timeout: config.requestTimeout
            });
            // Configure PDF options
            const pdfOptions = {
                format: options?.format || 'A4',
                landscape: options?.orientation === 'landscape',
                margin: {
                    top: options?.margin?.top || '1cm',
                    right: options?.margin?.right || '1cm',
                    bottom: options?.margin?.bottom || '1cm',
                    left: options?.margin?.left || '1cm'
                },
                displayHeaderFooter: options?.displayHeaderFooter || false,
                headerTemplate: options?.headerTemplate || '',
                footerTemplate: options?.footerTemplate || '',
                printBackground: options?.printBackground !== false,
                scale: options?.scale || 1,
                timeout: config.requestTimeout
            };
            // Generate PDF
            const pdfData = await page.pdf(pdfOptions);
            return Buffer.from(pdfData);
        }
        finally {
            await page.close();
        }
    }
    async cleanup() {
        if (this.activeBrowser) {
            await this.activeBrowser.close();
            this.activeBrowser = null;
        }
    }
}
