import puppeteer from 'puppeteer';
import crypto from 'crypto';
import fs from 'node:fs';
import { config } from '../config/index.js';
export class AuditService {
    activeBrowser = null;
    jobStatuses = new Map();
    jobResults = new Map();
    activeJobs = 0;
    maxConcurrentJobs = 1;
    // ---------- Browser boot ----------
    pickExecutablePath() {
        const candidates = [
            process.env.PUPPETEER_EXECUTABLE_PATH,
            '/usr/bin/google-chrome-stable',
            '/usr/bin/chromium',
            '/usr/bin/chromium-browser',
        ].filter(Boolean);
        for (const p of candidates) {
            try {
                if (fs.existsSync(p))
                    return p;
            }
            catch { /* ignore */ }
        }
        return undefined;
    }
    async launchBrowser() {
        const executablePath = this.pickExecutablePath();
        // Pipe transport is lighter than WS on small instances
        const usePipe = true;
        const args = [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--no-first-run',
            '--no-zygote',
            '--disable-gpu',
            '--hide-scrollbars',
            '--mute-audio',
            '--disable-extensions',
            '--user-data-dir=/tmp/chrome-data',
            // keep Chrome lean + prevent CodeRange OOM
            '--renderer-process-limit=1',
            '--js-flags=--jitless',
            // trim background work a bit more
            '--disable-background-networking',
            '--disable-background-timer-throttling',
            '--disable-renderer-backgrounding',
            '--disable-ipc-flooding-protection',
            '--metrics-recording-only',
        ];
        const launchOpts = {
            headless: true,
            pipe: usePipe,
            executablePath,
            args,
            timeout: 120_000,
            protocolTimeout: 180_000,
            dumpio: false,
        };
        console.log({
            node: process.version,
            executablePath: executablePath ?? '(not found)',
            pipeMode: usePipe,
            timestamp: new Date().toISOString(),
        });
        return puppeteer.launch(launchOpts);
    }
    async getBrowser() {
        if (!this.activeBrowser || !this.activeBrowser.isConnected()) {
            // close any stale instance
            try {
                await this.activeBrowser?.close();
            }
            catch { /* ignore */ }
            this.activeBrowser = await this.launchBrowser();
        }
        return this.activeBrowser;
    }
    // ---------- Public API ----------
    async startAudit(request) {
        if (this.activeJobs >= this.maxConcurrentJobs) {
            throw new Error('Maximum concurrent jobs reached');
        }
        // fire-and-forget (no await) – but we still guard all errors inside
        this.processAudit(request);
    }
    async getAuditStatus(jobId) {
        return this.jobStatuses.get(jobId) || null;
    }
    async getAuditDetails(jobId) {
        return this.jobResults.get(jobId) || null;
    }
    async cleanup() {
        try {
            await this.activeBrowser?.close();
        }
        catch { /* ignore */ }
        this.activeBrowser = null;
    }
    // ---------- Core flow ----------
    async processAudit(request) {
        this.activeJobs++;
        this.jobStatuses.set(request.jobId, 'PROCESSING');
        let page = null;
        try {
            console.log(`[audit] job ${request.jobId} → ${request.websiteUrl}`);
            // Quick preflight: don’t spawn Chrome if URL is dead
            try {
                const ctrl = new AbortController();
                const t = setTimeout(() => ctrl.abort(), 8_000);
                const head = await fetch(request.websiteUrl, { method: 'HEAD', signal: ctrl.signal });
                clearTimeout(t);
                console.log('[audit] preflight:', head.status);
            }
            catch (e) {
                throw new Error(`Preflight failed: ${e.message}`);
            }
            // Launch with a small retry
            let browser = null;
            for (let i = 0; i < 2; i++) {
                try {
                    console.log(`[audit] launching browser (attempt ${i + 1}/2)`);
                    browser = await this.getBrowser();
                    break;
                }
                catch (e) {
                    if (i === 1)
                        throw e;
                    await new Promise(r => setTimeout(r, 2_000));
                }
            }
            if (!browser)
                throw new Error('Browser failed to launch');
            // Create page with watchdog (fail fast if renderer dies)
            page = await this.createPageWithWatchdog(browser, 25_000);
            this.hookPageLogs(page);
            // Job-level watchdog so we never hang forever
            const jobWatchdog = new Promise((_, rej) => setTimeout(() => rej(new Error('Job watchdog timeout')), 120_000));
            const result = await Promise.race([
                this.runSinglePageAudit(page, request),
                jobWatchdog,
            ]);
            // persist + callback
            this.jobStatuses.set(request.jobId, 'COMPLETED');
            this.jobResults.set(request.jobId, result);
            console.log(`[audit] job ${request.jobId} completed`, {
                performance: result.results?.performanceScore,
                seo: result.results?.seoScore,
                accessibility: result.results?.accessibilityScore,
                bestPractices: result.results?.bestPracticesScore,
            });
            this.sendCallback(result).catch(err => console.warn('[callback] error (ignored):', err));
        }
        catch (error) {
            const errText = error instanceof Error ? `${error.name}: ${error.message}` : 'Unknown error';
            console.error(`[audit] job ${request.jobId} failed:`, errText);
            const fail = { jobId: request.jobId, status: 'FAILED', error: errText };
            this.jobStatuses.set(request.jobId, 'FAILED');
            this.jobResults.set(request.jobId, fail);
            this.sendCallback(fail).catch(err => console.warn('[callback] error (ignored):', err));
        }
        finally {
            // Close page first
            try {
                await page?.close({ runBeforeUnload: false });
            }
            catch { /* ignore */ }
            // Try graceful browser close after each job to prevent leaks
            try {
                await this.activeBrowser?.close();
            }
            catch { /* ignore */ }
            // If Chrome is wedged, hard kill the child proc
            try {
                this.activeBrowser?.process()?.kill('SIGKILL');
            }
            catch { /* ignore */ }
            this.activeBrowser = null;
            this.activeJobs--;
        }
    }
    // ---------- Helpers ----------
    async createPageWithWatchdog(browser, timeoutMs) {
        console.log('[audit] creating page…');
        const created = await Promise.race([
            (async () => {
                const p = await browser.newPage();
                console.log('[audit] page created');
                return p;
            })(),
            new Promise((_, rej) => setTimeout(() => rej(new Error('newPage() watchdog timeout')), timeoutMs)),
        ]);
        return created;
    }
    hookPageLogs(page) {
        page.on('console', m => console.log('[console]', m.type(), m.text()));
        page.on('pageerror', e => console.warn('[pageerror]', e.message));
        page.on('requestfailed', r => console.warn('[requestfailed]', r.url(), r.failure()?.errorText));
    }
    async runSinglePageAudit(page, request) {
        const ua = request.options?.customUserAgent || config?.lighthouse?.settings?.emulatedUserAgent || 'Mozilla/5.0';
        console.log('[audit] setUserAgent');
        await page.setUserAgent(ua);
        console.log('[audit] setViewport');
        if (request.options?.mobile) {
            await page.setViewport({ width: 375, height: 667, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
        }
        else {
            const w = config?.lighthouse?.settings?.screenEmulation?.width ?? 1366;
            const h = config?.lighthouse?.settings?.screenEmulation?.height ?? 768;
            await page.setViewport({ width: w, height: h, deviceScaleFactor: 1 });
        }
        console.log('[audit] set timeouts');
        page.setDefaultTimeout(60_000);
        page.setDefaultNavigationTimeout(60_000);
        console.log('[audit] navigating', request.websiteUrl);
        const response = await this.progressiveGoto(page, request.websiteUrl);
        console.log('[audit] navigation ok:', response?.status());
        // Collect metrics defensively
        console.log('[audit] collecting metrics');
        const perfJson = await page
            .evaluate(() => {
            try {
                return JSON.stringify(performance.getEntriesByType('navigation'));
            }
            catch {
                return '[]';
            }
        })
            .catch(() => '[]');
        let loadTime = 0;
        try {
            const nav = JSON.parse(perfJson);
            const nav0 = nav?.[0] ?? {};
            loadTime = Number.isFinite(nav0.loadEventEnd) ? Math.floor(nav0.loadEventEnd) : 0;
        }
        catch { /* ignore */ }
        const performanceScore = Math.max(0, Math.min(100, 100 - Math.floor(loadTime / 100)));
        // Basic SEO
        console.log('[audit] SEO checks');
        const seoScore = await page
            .evaluate(() => {
            try {
                const title = document.title || '';
                const metaDescription = document.querySelector('meta[name="description"]')?.getAttribute('content');
                const h1s = document.querySelectorAll('h1');
                let score = 0;
                if (title && title.length <= 60)
                    score += 25;
                if (metaDescription && metaDescription.length > 0)
                    score += 25;
                if (h1s.length === 1)
                    score += 25;
                if (document.querySelector('meta[name="viewport"]'))
                    score += 25;
                return score;
            }
            catch {
                return 50;
            }
        })
            .catch(() => 50);
        // Basic a11y
        console.log('[audit] accessibility checks');
        const accessibilityScore = await page
            .evaluate(() => {
            try {
                const images = Array.from(document.querySelectorAll('img'));
                const buttons = Array.from(document.querySelectorAll('button'));
                let score = 100;
                for (const img of images) {
                    if (!img.getAttribute('alt'))
                        score -= 10;
                }
                for (const btn of buttons) {
                    const hasText = !!btn.textContent?.trim();
                    const hasLabel = !!btn.getAttribute('aria-label');
                    if (!hasText && !hasLabel)
                        score -= 5;
                }
                return Math.max(0, score);
            }
            catch {
                return 70;
            }
        })
            .catch(() => 70);
        // Optional screenshot
        let screenshot;
        if (request.options?.includeScreenshot) {
            console.log('[audit] screenshot');
            try {
                const buf = await page.screenshot({ type: 'png', fullPage: false });
                screenshot = Buffer.from(buf).toString('base64');
            }
            catch (e) {
                console.warn('[audit] screenshot failed:', e.message);
            }
        }
        const results = {
            performanceScore,
            seoScore,
            accessibilityScore: Math.round(accessibilityScore),
            bestPracticesScore: 75,
            metrics: {
                loadTime,
                cumulativeLayoutShift: 0,
            },
            pagesCrawled: 1,
            screenshot,
            issues: [],
        };
        return { jobId: request.jobId, status: 'COMPLETED', results };
    }
    async progressiveGoto(page, url) {
        const attempts = [
            { name: 'domcontentloaded', opts: { waitUntil: 'domcontentloaded', timeout: 15_000 } },
            { name: 'load', opts: { waitUntil: 'load', timeout: 20_000 } },
            { name: 'networkidle2', opts: { waitUntil: 'networkidle2', timeout: 25_000 } },
            { name: 'basic', opts: { timeout: 15_000 } },
        ];
        for (const { name, opts } of attempts) {
            try {
                console.log(`[audit] goto (${name})`, opts);
                const res = await page.goto(url, opts);
                if (!res || res.status() >= 400) {
                    console.warn(`[audit] goto (${name}) status ${res?.status()}`);
                }
                else {
                    return res;
                }
            }
            catch (e) {
                console.warn(`[audit] goto (${name}) failed:`, e.message);
            }
        }
        throw new Error('Navigation failed after multiple strategies');
    }
    // ---------- Optional: issue extraction scaffold (unused for now) ----------
    /* eslint-disable @typescript-eslint/no-unused-vars */
    extractIssues(_lhr) {
        const issues = [];
        return issues;
    }
    /* eslint-enable @typescript-eslint/no-unused-vars */
    // ---------- Callback ----------
    async sendCallback(result) {
        if (!config.callbackUrl) {
            console.log('[callback] no callbackUrl configured – skipping');
            return;
        }
        try {
            const body = JSON.stringify(result);
            const signature = crypto.createHmac('sha256', config.webhookSecret).update(body).digest('hex');
            const controller = new AbortController();
            const t = setTimeout(() => controller.abort(), 15_000);
            const resp = await fetch(config.callbackUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Signature': `sha256=${signature}`,
                    'X-API-Key': config.apiKey,
                },
                body,
                signal: controller.signal,
            }).catch((e) => {
                clearTimeout(t);
                throw e;
            });
            clearTimeout(t);
            if (!resp.ok) {
                console.error('[callback] failed:', resp.status, resp.statusText);
                const text = await resp.text().catch(() => '');
                if (text)
                    console.error('[callback] body:', text);
            }
            else {
                console.log('[callback] ok');
            }
        }
        catch (e) {
            if (e.name === 'AbortError') {
                console.error('[callback] timeout');
            }
            else {
                console.error('[callback] error:', e.message);
            }
        }
    }
}
