import type { AuditResults } from '../types/audit.js';
export interface BrandingConfig {
    companyName?: string;
    logoUrl?: string;
    primaryColor?: string;
    secondaryColor?: string;
    website?: string;
    contactEmail?: string;
}
export interface ReportData {
    auditId: string;
    websiteUrl: string;
    completedAt: Date;
    createdAt: Date;
    results: AuditResults;
    branding: BrandingConfig;
}
export declare class HTMLTemplateService {
    /**
     * Generate a complete HTML report for PDF generation
     */
    generateHTMLReport(data: ReportData): string;
    private getBaseStyles;
    private getCustomStyles;
    private generateHeaderSection;
    private generatePageHeader;
    private generateExecutiveSummary;
    private generateKeyMetrics;
    private generateTopIssues;
    private generatePerformanceSection;
    private generateWebVitalsSection;
    private generateSEOSection;
    private generateSEOIssues;
    private generateAccessibilitySection;
    private generateAccessibilityIssues;
    private generateBestPracticesSection;
    private generateBestPracticesIssues;
    private generateDetailedIssues;
    private generateSummarySection;
    private generateRecommendations;
    private generateFooter;
}
