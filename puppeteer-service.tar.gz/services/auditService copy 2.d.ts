export interface AuditRequest {
    jobId: string;
    websiteUrl: string;
    priority?: number;
    options?: {
        mobile?: boolean;
        includeScreenshot?: boolean;
        customUserAgent?: string;
    };
}
export interface AuditResult {
    jobId: string;
    status: 'COMPLETED' | 'FAILED';
    results?: {
        performanceScore?: number;
        seoScore?: number;
        accessibilityScore?: number;
        bestPracticesScore?: number;
        issues?: Array<{
            type: 'ERROR' | 'WARNING' | 'INFO';
            category: 'PERFORMANCE' | 'SEO' | 'ACCESSIBILITY' | 'BEST_PRACTICES';
            title: string;
            description: string;
            impact: 'HIGH' | 'MEDIUM' | 'LOW';
            recommendation: string;
        }>;
        metrics?: {
            loadTime?: number;
            cumulativeLayoutShift?: number;
        };
        pagesCrawled?: number;
        screenshot?: string;
    };
    error?: string;
}
export declare class AuditService {
    private activeBrowser;
    private jobStatuses;
    private jobResults;
    private activeJobs;
    private readonly maxConcurrentJobs;
    private pickExecutablePath;
    private launchBrowser;
    private getBrowser;
    startAudit(request: AuditRequest): Promise<void>;
    getAuditStatus(jobId: string): Promise<string | null>;
    getAuditDetails(jobId: string): Promise<AuditResult | null>;
    cleanup(): Promise<void>;
    private processAudit;
    private createPageWithWatchdog;
    private hookPageLogs;
    private runSinglePageAudit;
    private progressiveGoto;
    private extractIssues;
    private sendCallback;
}
