export interface AuditRequest {
    jobId: string;
    websiteUrl: string;
    priority?: number;
    options?: {
        mobile?: boolean;
        includeScreenshot?: boolean;
        customUserAgent?: string;
        includePageSpeedInsights?: boolean;
    };
}
export interface AuditResult {
    jobId: string;
    status: 'COMPLETED' | 'FAILED';
    results?: {
        performanceScore?: number;
        seoScore?: number;
        accessibilityScore?: number;
        bestPracticesScore?: number;
        issues?: Array<{
            type: 'ERROR' | 'WARNING' | 'INFO';
            category: 'PERFORMANCE' | 'SEO' | 'ACCESSIBILITY' | 'BEST_PRACTICES';
            title: string;
            description: string;
            impact: 'HIGH' | 'MEDIUM' | 'LOW';
            recommendation: string;
        }>;
        metrics?: {
            loadTime?: number;
            cumulativeLayoutShift?: number;
        };
        pageSpeedMetrics?: {
            desktop?: {
                performanceScore?: number;
                firstContentfulPaint?: number;
                largestContentfulPaint?: number;
                firstInputDelay?: number;
                cumulativeLayoutShift?: number;
                speedIndex?: number;
                totalBlockingTime?: number;
            };
            mobile?: {
                performanceScore?: number;
                firstContentfulPaint?: number;
                largestContentfulPaint?: number;
                firstInputDelay?: number;
                cumulativeLayoutShift?: number;
                speedIndex?: number;
                totalBlockingTime?: number;
            };
        };
        categoryDetails?: {
            performance?: {
                score: number;
                items: Array<{
                    title: string;
                    value: string | number;
                    status: 'PASS' | 'FAIL' | 'WARNING';
                    description: string;
                }>;
            };
            seo?: {
                score: number;
                items: Array<{
                    title: string;
                    value: string | number;
                    status: 'PASS' | 'FAIL' | 'WARNING';
                    description: string;
                }>;
            };
            accessibility?: {
                score: number;
                items: Array<{
                    title: string;
                    value: string | number;
                    status: 'PASS' | 'FAIL' | 'WARNING';
                    description: string;
                }>;
            };
            bestPractices?: {
                score: number;
                items: Array<{
                    title: string;
                    value: string | number;
                    status: 'PASS' | 'FAIL' | 'WARNING';
                    description: string;
                }>;
            };
        };
        pagesCrawled?: number;
        screenshot?: string;
    };
    error?: string;
}
export declare class AuditService {
    private activeBrowser;
    private jobStatuses;
    private jobResults;
    private activeJobs;
    private readonly maxConcurrentJobs;
    private queue;
    private pumping;
    private readonly TIME;
    private normalizeAndValidateUrl;
    private pickExecutablePath;
    private launchBrowser;
    private getBrowser;
    private getBrowserWithRetry;
    startAudit(request: AuditRequest): Promise<void>;
    private pumpQueue;
    getAuditStatus(jobId: string): Promise<string | null>;
    getAuditDetails(jobId: string): Promise<AuditResult | null>;
    cleanup(): Promise<void>;
    private getPageSpeedInsights;
    private fetchPageSpeedStrategy;
    private processAudit;
    private createPageWithWatchdog;
    private hookPageLogs;
    private runSinglePageAudit;
    private progressiveGoto;
    private extractIssues;
    private sendCallback;
}
