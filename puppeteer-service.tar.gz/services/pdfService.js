// services/pdfService.ts
import puppeteer from 'puppeteer';
import fs from 'node:fs';
import { config } from '../config/index.js';
export class PDFService {
    activeBrowser = null;
    // --- Browser bootstrap -----------------------------------------------------
    pickExecutablePath() {
        const candidates = [
            process.env.PUPPETEER_EXECUTABLE_PATH,
            config.chromeExecutablePath, // allow config to supply a path
            '/usr/bin/google-chrome-stable',
            '/usr/bin/chromium',
            '/usr/bin/chromium-browser',
        ].filter(Boolean);
        for (const p of candidates) {
            try {
                if (p && fs.existsSync(p))
                    return p;
            }
            catch { /* ignore */ }
        }
        return undefined; // let Puppeteer pick bundled/available one
    }
    async launchBrowser() {
        const executablePath = this.pickExecutablePath();
        const args = [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--no-first-run',
            '--no-zygote',
            '--disable-gpu',
            '--hide-scrollbars',
            '--mute-audio',
            '--disable-extensions',
            '--user-data-dir=/tmp/chrome-data',
            // DO NOT set --single-process or remote debugging flags in prod
        ];
        const launchOpts = {
            headless: true, // headless 'new' is default in recent Puppeteer
            executablePath,
            args,
            timeout: 45_000, // launch timeout
            protocolTimeout: 60_000, // CDP timeout
            dumpio: false,
        };
        return puppeteer.launch(launchOpts);
    }
    async getBrowser() {
        if (!this.activeBrowser || !this.activeBrowser.isConnected()) {
            // Close any zombie browser
            if (this.activeBrowser) {
                try {
                    await this.activeBrowser.close();
                }
                catch { /* ignore */ }
                this.activeBrowser = null;
            }
            this.activeBrowser = await this.launchBrowser();
        }
        return this.activeBrowser;
    }
    // --- Public API ------------------------------------------------------------
    async generatePDF(request) {
        const browser = await this.getBrowserWithRetries();
        const page = await browser.newPage();
        // Helpful logs for diagnosing page issues in containers
        page.on('console', m => console.log('[pdf][console]', m.type(), m.text()));
        page.on('pageerror', e => console.warn('[pdf][pageerror]', e.message));
        page.on('requestfailed', r => console.warn('[pdf][requestfailed]', r.url(), r.failure()?.errorText));
        try {
            // Load the HTML string
            await this.setHTMLContent(page, request.htmlContent);
            // Ensure print CSS takes effect and fonts are ready
            await page.emulateMediaType('print');
            await this.waitForFonts(page);
            // Build PDF options safely
            const pdfOptions = this.buildPdfOptions(request.options);
            // Generate PDF
            const pdf = await page.pdf(pdfOptions);
            return Buffer.from(pdf);
        }
        finally {
            try {
                await page.close();
            }
            catch { /* ignore */ }
            // Intentionally keep the browser alive for reuse; use cleanup() to close
        }
    }
    async generatePDFFromURL(url, options) {
        // Quick preflight so we don’t waste a Chrome spin-up on dead URLs
        await this.preflightURL(url);
        const browser = await this.getBrowserWithRetries();
        const page = await browser.newPage();
        page.on('console', m => console.log('[pdf-url][console]', m.type(), m.text()));
        page.on('pageerror', e => console.warn('[pdf-url][pageerror]', e.message));
        page.on('requestfailed', r => console.warn('[pdf-url][requestfailed]', r.url(), r.failure()?.errorText));
        try {
            // Progressive navigation strategies for flaky pages/CDN
            await this.progressiveGoto(page, url, config.requestTimeout ?? 60_000);
            await page.emulateMediaType('print');
            await this.waitForFonts(page);
            const pdfOptions = this.buildPdfOptions(options);
            const pdf = await page.pdf(pdfOptions);
            return Buffer.from(pdf);
        }
        finally {
            try {
                await page.close();
            }
            catch { /* ignore */ }
        }
    }
    async cleanup() {
        if (this.activeBrowser) {
            try {
                await this.activeBrowser.close();
            }
            catch { /* ignore */ }
            this.activeBrowser = null;
        }
    }
    // --- Internals -------------------------------------------------------------
    async getBrowserWithRetries(maxRetries = 2) {
        let attempt = 0;
        let lastErr;
        while (attempt <= maxRetries) {
            try {
                return await this.getBrowser();
            }
            catch (err) {
                lastErr = err;
                attempt++;
                // try to close and relaunch on failure
                if (this.activeBrowser) {
                    try {
                        await this.activeBrowser.close();
                    }
                    catch { /* ignore */ }
                    this.activeBrowser = null;
                }
                if (attempt > maxRetries)
                    break;
                const backoff = 1000 * attempt;
                console.warn(`[pdf] browser launch attempt ${attempt} failed; retrying in ${backoff}ms`, err);
                await new Promise(res => setTimeout(res, backoff));
            }
        }
        throw new Error(`Failed to launch browser after ${maxRetries + 1} attempts: ${lastErr?.message ?? lastErr}`);
    }
    async setHTMLContent(page, html) {
        // Use a watchdog to avoid indefinite hangs in setContent
        const timeout = config.requestTimeout ?? 60_000;
        const watchdog = new Promise((_, rej) => setTimeout(() => rej(new Error('setContent watchdog timeout')), Math.min(timeout, 90_000)));
        await Promise.race([
            page.setContent(html, { waitUntil: 'networkidle0', timeout }),
            watchdog,
        ]);
    }
    async waitForFonts(page) {
        try {
            // Wait for all fonts (important for correct pagination/widths)
            await page.evaluate(() => document.fonts?.ready?.then(() => true));
        }
        catch {
            // Not critical if fonts API isn’t available
        }
    }
    buildPdfOptions(options) {
        // Chrome requires non-empty templates when displayHeaderFooter=true
        const wantsHeaderFooter = !!options?.displayHeaderFooter;
        const safeHeader = wantsHeaderFooter
            ? (options?.headerTemplate ?? `<div style="font-size:8px;width:100%;text-align:center;"></div>`)
            : undefined;
        const safeFooter = wantsHeaderFooter
            ? (options?.footerTemplate ?? `<div style="font-size:8px;width:100%;text-align:center;"><span class="pageNumber"></span>/<span class="totalPages"></span></div>`)
            : undefined;
        const pdfOptions = {
            // Respect CSS @page size when present
            preferCSSPageSize: true,
            format: options?.format ?? 'A4',
            landscape: options?.orientation === 'landscape',
            margin: {
                top: options?.margin?.top ?? '1cm',
                right: options?.margin?.right ?? '1cm',
                bottom: options?.margin?.bottom ?? (wantsHeaderFooter ? '1.2cm' : '1cm'),
                left: options?.margin?.left ?? '1cm',
            },
            displayHeaderFooter: wantsHeaderFooter,
            headerTemplate: safeHeader,
            footerTemplate: safeFooter,
            printBackground: options?.printBackground !== false,
            scale: options?.scale ?? 1,
            timeout: config.requestTimeout ?? 60_000,
        };
        return pdfOptions;
    }
    async preflightURL(url) {
        try {
            const controller = new AbortController();
            const t = setTimeout(() => controller.abort(), 10_000);
            const res = await fetch(url, { method: 'HEAD', signal: controller.signal });
            clearTimeout(t);
            if (!res.ok) {
                console.warn('[pdf] preflight HEAD not OK:', res.status, res.statusText);
            }
        }
        catch (e) {
            // Not fatal—some servers block HEAD. We’ll still try to navigate.
            console.warn('[pdf] preflight HEAD failed:', e?.message);
        }
    }
    async progressiveGoto(page, url, totalTimeoutMs) {
        const strategies = [
            { name: 'domcontentloaded', waitUntil: 'domcontentloaded', timeout: Math.min(20_000, totalTimeoutMs) },
            { name: 'load', waitUntil: 'load', timeout: Math.min(35_000, totalTimeoutMs) },
            { name: 'networkidle2', waitUntil: 'networkidle2', timeout: Math.min(45_000, totalTimeoutMs) },
            { name: 'basic', waitUntil: undefined, timeout: Math.min(15_000, totalTimeoutMs) },
        ];
        for (const s of strategies) {
            try {
                const opts = { timeout: s.timeout };
                if (s.waitUntil)
                    opts.waitUntil = s.waitUntil;
                const resp = await page.goto(url, opts);
                // Accept non-OK (e.g., 204/pdf, 3xx when content renders) as long as it loaded
                if (resp)
                    return;
            }
            catch (e) {
                console.warn(`[pdf] goto strategy "${s.name}" failed:`, e?.message);
            }
        }
        throw new Error('All navigation strategies failed');
    }
}
