import { type Browser } from 'puppeteer';
export interface AuditRequest {
    jobId: string;
    websiteUrl: string;
    priority?: number;
    options?: {
        mobile?: boolean;
        includeScreenshot?: boolean;
        customUserAgent?: string;
    };
}
export interface AuditResult {
    jobId: string;
    status: 'COMPLETED' | 'FAILED';
    results?: {
        performanceScore?: number;
        seoScore?: number;
        accessibilityScore?: number;
        bestPracticesScore?: number;
        issues?: Array<{
            type: 'ERROR' | 'WARNING' | 'INFO';
            category: 'PERFORMANCE' | 'SEO' | 'ACCESSIBILITY' | 'BEST_PRACTICES';
            title: string;
            description: string;
            impact: 'HIGH' | 'MEDIUM' | 'LOW';
            recommendation: string;
        }>;
        metrics?: {
            loadTime?: number;
            cumulativeLayoutShift?: number;
        };
        pagesCrawled?: number;
        screenshot?: string;
    };
    error?: string;
}
export declare class AuditService {
    private activeBrowser;
    private jobStatuses;
    private jobResults;
    private activeJobs;
    private readonly maxConcurrentJobs;
    private pickExecutablePath;
    getBrowser(): Promise<Browser>;
    startAudit(request: AuditRequest): Promise<void>;
    processAudit(request: AuditRequest): Promise<void>;
    private runLighthouseAudit;
    private extractIssues;
    private sendCallback;
    getAuditStatus(jobId: string): Promise<string | null>;
    getAuditDetails(jobId: string): Promise<AuditResult | null>;
    cleanup(): Promise<void>;
}
