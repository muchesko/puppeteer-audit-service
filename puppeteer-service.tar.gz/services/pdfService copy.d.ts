import { Browser } from 'puppeteer';
export interface PDFRequest {
    jobId: string;
    htmlContent: string;
    options?: {
        format?: 'A4' | 'Letter';
        orientation?: 'portrait' | 'landscape';
        margin?: {
            top?: string;
            right?: string;
            bottom?: string;
            left?: string;
        };
        displayHeaderFooter?: boolean;
        headerTemplate?: string;
        footerTemplate?: string;
        printBackground?: boolean;
        scale?: number;
    };
}
export declare class PDFService {
    private activeBrowser;
    getBrowser(): Promise<Browser>;
    generatePDF(request: PDFRequest): Promise<Buffer>;
    generatePDFFromURL(url: string, options?: PDFRequest['options']): Promise<Buffer>;
    cleanup(): Promise<void>;
}
