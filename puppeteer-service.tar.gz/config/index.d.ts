import 'dotenv/config';
export declare const config: {
    port: number;
    nodeEnv: string;
    apiSecretKey: string;
    webhookSecret: string;
    apiKey: string;
    callbackUrl: string;
    pageSpeedApiKey: string;
    chromeExecutablePath: string;
    puppeteerSkipDownload: boolean;
    maxConcurrentJobs: number;
    requestTimeout: number;
    memoryLimit: number;
    lighthouse: {
        settings: {
            maxWaitForFcp: number;
            maxWaitForLoad: number;
            formFactor: "desktop";
            throttling: {
                rttMs: number;
                throughputKbps: number;
                cpuSlowdownMultiplier: number;
                requestLatencyMs: number;
                downloadThroughputKbps: number;
                uploadThroughputKbps: number;
            };
            screenEmulation: {
                mobile: boolean;
                width: number;
                height: number;
                deviceScaleFactor: number;
                disabled: boolean;
            };
            emulatedUserAgent: string;
        };
        config: {
            extends: string;
            settings: {
                onlyAudits: string[];
            };
        };
    };
};
